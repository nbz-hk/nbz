#include "beurk.h"

int main() {
    is_attacker();
    is_hidden_file("");
    is_procnet("");

    return 0;
}
