/** it seems impossible to check this function
 * outside of functional tests
 * leaving it empty...
 */

void    test_cleanup_login_records(unsigned int *count, unsigned int *total) {
    ;
}
