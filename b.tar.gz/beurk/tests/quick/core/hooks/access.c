#include <unistd.h>

int main(void) {
    access("tata", 0);
}
