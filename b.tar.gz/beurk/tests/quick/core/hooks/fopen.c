#include <stdio.h>

int     main(void) {
    fopen("tata", "r");
}
