#include <unistd.h>

int main(void) {
    link("foo", "bar");
}
