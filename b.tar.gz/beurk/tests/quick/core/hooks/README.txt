these basic tests are designed to verify if functions are
properly hooked, by checking beurk's debug message output.

adding a function hook test:

    1. create a <HOOK>.c file that does basic tests
    2. add the tests in run.py
