#include <unistd.h>

int main(void) {
    unlink("foo");
}
