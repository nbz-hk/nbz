#include <unistd.h>

int main(void) {
    rmdir("tata");
}
