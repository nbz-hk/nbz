The WM need to be infected for that unit tests pass.

VICTIM use limited vagrant user. But we can use sudo to run a commamd as root (no password)

## Add a unit test

the file need to finish .test
